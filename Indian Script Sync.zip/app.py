from flask import Flask, render_template, request, jsonify, session
import pandas as pd
import json
from deep_translator import GoogleTranslator
import os
import re
from collections import Counter

app = Flask(__name__)
app.secret_key = 'indian_languages_analysis_2024'

# Load the dataset
def load_data():
    df = pd.read_csv('data/languages_database.csv')
    return df

# Get unique states
def get_states():
    df = load_data()
    return df['State'].unique().tolist()

# Get unique languages
def get_languages():
    df = load_data()
    return df['Languages'].unique().tolist()

# Supported Indian languages for translation
SUPPORTED_LANGUAGES = {
    'hi': 'Hindi',
    'bn': 'Bengali',
    'te': 'Telugu',
    'mr': 'Marathi',
    'ta': 'Tamil',
    'gu': 'Gujarati',
    'kn': 'Kannada',
    'ml': 'Malayalam',
    'pa': 'Punjabi',
    'or': 'Odia',
    'ur': 'Urdu',
    'as': 'Assamese',
    'ne': 'Nepali',
    'sd': 'Sindhi',
    'en': 'English'
}

# Language code mapping for TTS
LANGUAGE_TTS_CODES = {
    'hi': 'hi-IN',
    'bn': 'bn-IN',
    'te': 'te-IN',
    'mr': 'mr-IN',
    'ta': 'ta-IN',
    'gu': 'gu-IN',
    'kn': 'kn-IN',
    'ml': 'ml-IN',
    'pa': 'pa-IN',
    'en': 'en-US',
    'ur': 'ur-PK',
    'ne': 'ne-NP',
    'or': 'or-IN',
    'as': 'as-IN',
    'sd': 'sd-IN'
}

# Unicode ranges for Indian scripts
SCRIPT_RANGES = {
    'Devanagari': (0x0900, 0x097F),
    'Bengali': (0x0980, 0x09FF),
    'Gurmukhi': (0x0A00, 0x0A7F),
    'Gujarati': (0x0A80, 0x0AFF),
    'Oriya': (0x0B00, 0x0B7F),
    'Tamil': (0x0B80, 0x0BFF),
    'Telugu': (0x0C00, 0x0C7F),
    'Kannada': (0x0C80, 0x0CFF),
    'Malayalam': (0x0D00, 0x0D7F),
    'Latin': (0x0041, 0x007A)
}

def detect_script(text):
    """Detect the script of given text"""
    script_counts = Counter()
    for char in text:
        code_point = ord(char)
        for script, (start, end) in SCRIPT_RANGES.items():
            if start <= code_point <= end:
                script_counts[script] += 1
                break
    return script_counts

def analyze_text(text):
    """Analyze text for various metrics"""
    words = text.split()
    sentences = re.split(r'[।.!?]', text)
    sentences = [s.strip() for s in sentences if s.strip()]
    
    return {
        'char_count': len(text),
        'word_count': len(words),
        'sentence_count': len(sentences),
        'avg_word_length': round(sum(len(w) for w in words) / max(len(words), 1), 2),
        'script_distribution': dict(detect_script(text))
    }

def simple_sentiment_analysis(text):
    """Simple sentiment analysis based on keywords"""
    positive_words = ['good', 'great', 'excellent', 'wonderful', 'amazing', 'happy', 'love', 'best', 'beautiful', 'fantastic',
                     'अच्छा', 'बहुत', 'प्यार', 'खुश', 'सुंदर', 'शानदार', 'बेहतरीन',
                     'நல்ல', 'அழகு', 'மகிழ்ச்சி', 'అద్భుతమైన', 'ভালো', 'সুন্দর']
    negative_words = ['bad', 'terrible', 'horrible', 'sad', 'hate', 'worst', 'ugly', 'awful', 'poor', 'disappointing',
                     'बुरा', 'दुख', 'नफरत', 'खराब', 'बेकार',
                     'கெட்ட', 'வருத்தம்', 'చెడ్డ', 'খারাপ', 'দুঃখ']
    
    text_lower = text.lower()
    pos_count = sum(1 for word in positive_words if word in text_lower)
    neg_count = sum(1 for word in negative_words if word in text_lower)
    
    if pos_count > neg_count:
        return {'sentiment': 'Positive', 'confidence': min(95, 60 + pos_count * 10), 'positive_count': pos_count, 'negative_count': neg_count}
    elif neg_count > pos_count:
        return {'sentiment': 'Negative', 'confidence': min(95, 60 + neg_count * 10), 'positive_count': pos_count, 'negative_count': neg_count}
    else:
        return {'sentiment': 'Neutral', 'confidence': 70, 'positive_count': pos_count, 'negative_count': neg_count}

def predict_language_from_text(text):
    """Predict the most likely language from text using script detection"""
    script_counts = detect_script(text)
    if not script_counts:
        return {'language': 'Unknown', 'confidence': 0}
    
    script_to_language = {
        'Devanagari': ['Hindi', 'Marathi', 'Nepali', 'Sanskrit'],
        'Bengali': ['Bengali', 'Assamese'],
        'Tamil': ['Tamil'],
        'Telugu': ['Telugu'],
        'Kannada': ['Kannada'],
        'Malayalam': ['Malayalam'],
        'Gujarati': ['Gujarati'],
        'Gurmukhi': ['Punjabi'],
        'Oriya': ['Odia'],
        'Latin': ['English']
    }
    
    most_common_script = script_counts.most_common(1)[0][0]
    total_chars = sum(script_counts.values())
    confidence = round((script_counts[most_common_script] / total_chars) * 100, 1)
    
    possible_languages = script_to_language.get(most_common_script, ['Unknown'])
    
    return {
        'script': most_common_script,
        'possible_languages': possible_languages,
        'confidence': confidence,
        'script_distribution': dict(script_counts)
    }

def get_language_statistics_for_prediction(language_name):
    """Get statistics about a language for prediction insights"""
    df = load_data()
    lang_data = df[df['Languages'].str.contains(language_name, case=False, na=False)]
    
    if lang_data.empty:
        return None
    
    return {
        'states_spoken': lang_data['State'].nunique(),
        'avg_percentage': round(lang_data['Percentage (%)'].mean(), 2),
        'max_percentage': round(lang_data['Percentage (%)'].max(), 2),
        'top_state': lang_data.loc[lang_data['Percentage (%)'].idxmax(), 'State'] if not lang_data.empty else 'N/A'
    }

# Home Page
@app.route('/')
def home():
    df = load_data()
    total_states = df['State'].nunique()
    total_languages = df['Languages'].nunique()
    return render_template('home.html', 
                         total_states=total_states, 
                         total_languages=total_languages)

# Dashboard Page
@app.route('/dashboard')
def dashboard():
    df = load_data()
    
    # Top languages by number of states
    language_counts = df.groupby('Languages')['State'].nunique().sort_values(ascending=False).head(10)
    top_languages = language_counts.to_dict()
    
    # State-wise language diversity
    state_diversity = df.groupby('State')['Languages'].count().sort_values(ascending=False).head(10)
    state_diversity_dict = state_diversity.to_dict()
    
    # Average percentage of dominant language per state
    dominant_lang = df.loc[df.groupby('State')['Percentage (%)'].idxmax()]
    
    return render_template('dashboard.html',
                         top_languages=top_languages,
                         state_diversity=state_diversity_dict,
                         dominant_lang=dominant_lang.to_dict('records'))

# Language Explorer Page
@app.route('/explorer')
def explorer():
    states = get_states()
    languages = get_languages()
    return render_template('explorer.html', states=states, languages=languages)

# API endpoint for state data
@app.route('/api/state/<state_name>')
def get_state_data(state_name):
    df = load_data()
    state_data = df[df['State'] == state_name].to_dict('records')
    return jsonify(state_data)

# API endpoint for language data
@app.route('/api/language/<language_name>')
def get_language_data(language_name):
    df = load_data()
    language_data = df[df['Languages'] == language_name].to_dict('records')
    return jsonify(language_data)

# Document Analysis Page
@app.route('/document-analysis')
def document_analysis():
    languages = get_languages()
    return render_template('document_analysis.html', languages=languages)

# Translation Page
@app.route('/translation')
def translation():
    return render_template('translation.html', languages=SUPPORTED_LANGUAGES, tts_codes=LANGUAGE_TTS_CODES)

# AI Features Page
@app.route('/ai-features')
def ai_features():
    return render_template('ai_features.html', languages=SUPPORTED_LANGUAGES)

# API endpoint for translation
@app.route('/api/translate', methods=['POST'])
def translate_text():
    try:
        data = request.json
        text = data.get('text', '')
        target_lang = data.get('target_lang', 'hi')
        source_lang = data.get('source_lang', 'auto')
        
        translator = GoogleTranslator(source=source_lang, target=target_lang)
        translated_text = translator.translate(text)
        
        return jsonify({
            'success': True,
            'original': text,
            'translated': translated_text,
            'source_lang': source_lang,
            'target_lang': target_lang,
            'tts_code': LANGUAGE_TTS_CODES.get(target_lang, 'en-US')
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

# API endpoint for document translation
@app.route('/api/translate-document', methods=['POST'])
def translate_document():
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'error': 'No file uploaded'})
        
        file = request.files['file']
        target_lang = request.form.get('target_lang', 'hi')
        source_lang = request.form.get('source_lang', 'auto')
        
        if file.filename == '':
            return jsonify({'success': False, 'error': 'No file selected'})
        
        # Read file content
        content = file.read().decode('utf-8')
        
        # Translate content
        translator = GoogleTranslator(source=source_lang, target=target_lang)
        
        # Split into chunks for large documents (Google Translate limit)
        max_chars = 4500
        chunks = [content[i:i+max_chars] for i in range(0, len(content), max_chars)]
        translated_chunks = [translator.translate(chunk) for chunk in chunks]
        translated_content = ''.join(translated_chunks)
        
        return jsonify({
            'success': True,
            'original': content,
            'translated': translated_content,
            'filename': file.filename,
            'source_lang': source_lang,
            'target_lang': target_lang,
            'char_count': len(content),
            'tts_code': LANGUAGE_TTS_CODES.get(target_lang, 'en-US')
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

# API endpoint for text analysis
@app.route('/api/analyze-text', methods=['POST'])
def api_analyze_text():
    try:
        data = request.json
        text = data.get('text', '')
        
        if not text:
            return jsonify({'success': False, 'error': 'No text provided'})
        
        analysis = analyze_text(text)
        language_prediction = predict_language_from_text(text)
        sentiment = simple_sentiment_analysis(text)
        
        # Get language statistics if we can identify the language
        lang_stats = None
        if language_prediction['possible_languages']:
            for lang in language_prediction['possible_languages']:
                stats = get_language_statistics_for_prediction(lang)
                if stats:
                    lang_stats = stats
                    lang_stats['language'] = lang
                    break
        
        return jsonify({
            'success': True,
            'analysis': analysis,
            'language_prediction': language_prediction,
            'sentiment': sentiment,
            'language_stats': lang_stats
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

# API endpoint for chatbot
@app.route('/api/chatbot', methods=['POST'])
def chatbot():
    try:
        data = request.json
        message = data.get('message', '').lower()
        
        df = load_data()
        
        # Simple rule-based chatbot responses
        response = ""
        
        if any(word in message for word in ['hello', 'hi', 'hey', 'namaste']):
            response = "Hello! I'm your Indian Languages Assistant. I can help you with:\n• Language statistics and information\n• Translation between Indian languages\n• Document analysis\n• State-wise language distribution\n\nTry asking me about any Indian language or state!"
        
        elif 'how many languages' in message:
            total_languages = df['Languages'].nunique()
            response = f"There are {total_languages} unique languages recorded in our database across various Indian states and union territories."
        
        elif 'how many states' in message:
            total_states = df['State'].nunique()
            response = f"Our database covers {total_states} states and union territories of India."
        
        elif 'most spoken' in message or 'most popular' in message:
            top_lang = df.groupby('Languages')['State'].nunique().sort_values(ascending=False).head(5)
            response = "The most widespread languages in India (by number of states):\n"
            for i, (lang, count) in enumerate(top_lang.items(), 1):
                response += f"{i}. {lang} - spoken in {count} states\n"
        
        elif 'highest percentage' in message or 'dominant' in message:
            highest = df.nlargest(5, 'Percentage (%)')
            response = "Languages with highest percentage in their states:\n"
            for _, row in highest.iterrows():
                response += f"• {row['Languages']} in {row['State']}: {row['Percentage (%)']}%\n"
        
        else:
            # Check if asking about a specific language
            for lang in df['Languages'].unique():
                if lang.lower() in message:
                    lang_data = df[df['Languages'] == lang]
                    states = lang_data['State'].tolist()
                    avg_pct = round(lang_data['Percentage (%)'].mean(), 2)
                    response = f"**{lang}**\n• Spoken in {len(states)} states: {', '.join(states[:5])}{'...' if len(states) > 5 else ''}\n• Average percentage: {avg_pct}%"
                    break
            
            # Check if asking about a specific state
            for state in df['State'].unique():
                if state.lower() in message:
                    state_data = df[df['State'] == state].sort_values('Percentage (%)', ascending=False)
                    response = f"**{state}**\nTop languages:\n"
                    for _, row in state_data.head(5).iterrows():
                        response += f"• {row['Languages']}: {row['Percentage (%)']}%\n"
                    break
        
        if not response:
            response = "I'm not sure about that. You can ask me about:\n• Specific languages (e.g., 'Tell me about Hindi')\n• Specific states (e.g., 'What languages are spoken in Kerala?')\n• General statistics (e.g., 'How many languages are there?')\n• Translation help"
        
        return jsonify({
            'success': True,
            'response': response
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

# API endpoint for language prediction
@app.route('/api/predict-language', methods=['POST'])
def api_predict_language():
    try:
        data = request.json
        text = data.get('text', '')
        
        if not text:
            return jsonify({'success': False, 'error': 'No text provided'})
        
        prediction = predict_language_from_text(text)
        
        # Get detailed stats for predicted language
        if prediction['possible_languages']:
            for lang in prediction['possible_languages']:
                stats = get_language_statistics_for_prediction(lang)
                if stats:
                    prediction['statistics'] = stats
                    break
        
        return jsonify({
            'success': True,
            'prediction': prediction
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

# Statistics Page
@app.route('/statistics')
def statistics():
    df = load_data()
    
    # Calculate various statistics
    stats = {
        'total_records': len(df),
        'total_states': df['State'].nunique(),
        'total_languages': df['Languages'].nunique(),
        'avg_languages_per_state': round(df.groupby('State')['Languages'].count().mean(), 2),
        'max_languages_state': df.groupby('State')['Languages'].count().idxmax(),
        'min_languages_state': df.groupby('State')['Languages'].count().idxmin(),
    }
    
    # Most spoken languages (by number of states)
    most_spoken = df.groupby('Languages')['State'].nunique().sort_values(ascending=False).head(15).to_dict()
    
    # Highest percentage languages
    highest_pct = df.nlargest(10, 'Percentage (%)')[['State', 'Languages', 'Percentage (%)']].to_dict('records')
    
    return render_template('statistics.html', 
                         stats=stats, 
                         most_spoken=most_spoken,
                         highest_pct=highest_pct)

# API endpoint for chart data
@app.route('/api/chart-data')
def chart_data():
    df = load_data()
    
    # Language distribution across states
    lang_distribution = df.groupby('Languages').agg({
        'State': 'nunique',
        'Percentage (%)': 'mean'
    }).round(2).reset_index()
    lang_distribution.columns = ['Language', 'States', 'AvgPercentage']
    
    return jsonify(lang_distribution.to_dict('records'))

# API endpoint for all data
@app.route('/api/all-data')
def all_data():
    df = load_data()
    return jsonify(df.to_dict('records'))

if __name__ == '__main__':
    app.run(debug=True)
